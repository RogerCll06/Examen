﻿namespace Examen.Models
{
    public class Exa_men
    {
        public List<Marca> MarcaList { get; set; }  
    }
}
